<?php require_once("header.php"); ?>

	<div class="container">
		<div class="row">
			<div class="col-3">
				<a href="main.php"><i class="fas fa-chevron-left text-primary"></i> Voltar</a>
			</div>
			<div class="col">
				<h6 class="text-center">Turistando</h6>
			</div>
			<div class="col-3">
				<i class="fas fa-bars menu float-right"></i>
			</div>
		</div>
	</div>

	<div class="container">
		<div class="row">
			<div class="col">
				<h4 class="text-center">Guias próximos</h4>
				<!-- <h6></h6> -->
			</div>
		</div>

		<div class="row">
			<div class="col p-0">
				<img src="images/mapa.jpg" width="100%" class="img-fluid">
			</div>
		</div>
	</div>
<?php require_once("footer.php"); ?>