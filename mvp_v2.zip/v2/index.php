<!DOCTYPE html>
<html>
<head>
	<title>MVP - Projeto Integrador 2 - V2</title>
	<style type="text/css">
		body
		{
			margin:0;
			padding:0;
		}
		iframe
		{
			background: url(images/iphone.png) no-repeat;
			padding: 105px 23px 110px 26px;
			border: 0;
			position: absolute;
			left: 0;
			right: 0;
			margin: 0 auto;
		}
	</style>
</head>
<body>
	<!-- <iframe src="app.php" width="370px" height="785"></iframe> -->
	<iframe src="app.php" width="320px" height="568px"></iframe>
</body>
</html>